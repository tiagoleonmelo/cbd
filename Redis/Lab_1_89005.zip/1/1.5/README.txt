Structures Used

Set used for the users of our Message App, since there can never be two users with the same name
Set used for the followers of each user, as well as what users a given user follows
List used for the messages of each user, to enable having them sorted by time and indexed
